<?php

namespace Longman\TelegramBot\Entities\InlineQuery;

interface InlineQueryResult
{

}
