<?php

namespace Longman\TelegramBot\Entities\InputMedia;

interface InputMedia
{

}
